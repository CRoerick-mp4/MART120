function setup() {
  createCanvas(400, 600);
  background(255);

  fill(220, 180, 150);
  noStroke();
  ellipse(200, 200, 150, 200);

  fill(255);
  ellipse(160, 160, 40, 40);
  ellipse(240, 160, 40, 40);

  fill(0);
  ellipse(160, 160, 15, 15);
  ellipse(240, 160, 15, 15);

  stroke(0);
  strokeWeight(2);
  line(170, 240, 230, 240);

  fill(220, 180, 150);
  triangle(200, 210, 195, 230, 205, 230);

  stroke(0);
  strokeWeight(4);
  line(140, 130, 180, 130);
  line(220, 130, 260, 130);

  fill(50, 50, 50);
  triangle(125, 120, 275, 120, 200, 50);

  fill(220, 180, 150);
  ellipse(100, 200, 40, 60);
  ellipse(300, 200, 40, 60);

  fill(0, 102, 204);
  rect(125, 350, 150, 200);

  fill(220, 180, 150);
  rect(75, 350, 50, 150);
  rect(275, 350, 50, 150);

  textSize(15);
  text('Carter Roerick', width / 2, height - 20);
}

function draw() {
}
