let shapes = [];
let player;
let gameWon = false;

function setup() {
  createCanvas(400, 400);
  
  for (let i = 0; i < 5; i++) {
    shapes.push({
      x: random(width),
      y: random(height),
      size: random(20, 40),
      xSpeed: random(-2, 2),
      ySpeed: random(-2, 2),
    });
  }

  player = {
    x: width / 2,
    y: height / 2,
    size: 30,
    speed: 3
  };
}

function draw() {
  background(255);

  for (let shape of shapes) {
    shape.x += shape.xSpeed;
    shape.y += shape.ySpeed;
    
    if (shape.x < 0 || shape.x > width) shape.xSpeed *= -1;
    if (shape.y < 0 || shape.y > height) shape.ySpeed *= -1;
    
    fill(random(255), random(255), random(255));
    noStroke();
    ellipse(shape.x, shape.y, shape.size);
  }

  fill(255, 0, 0);
  ellipse(player.x, player.y, player.size);

  if (player.x < 0 || player.x > width || player.y < 0 || player.y > height) {
    gameWon = true;
  }

  if (gameWon) {
    fill(0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("You Win!", width / 2, height / 2);
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    player.x -= player.speed;
  } else if (keyCode === RIGHT_ARROW) {
    player.x += player.speed;
  } else if (keyCode === UP_ARROW) {
    player.y -= player.speed;
  } else if (keyCode === DOWN_ARROW) {
    player.y += player.speed;
  }
}
