let shapes = [];
let player;
let gameWon = false;

function setup() {
  createCanvas(400, 400);
  createPlayer();
  createObstacles(2);
}

function draw() {
  background(255);
  
  drawBorders();
  drawExit();
  movePlayer();
  moveObstacles();
  drawPlayer();
  drawShapes();

  if (gameWon) {
    displayWinMessage();
  }
}

function createPlayer() {
  player = {
    x: width / 2,
    y: height / 2,
    size: 30,
    speed: 3
  };
}

function movePlayer() {
  if (keyIsDown(LEFT_ARROW)) {
    player.x -= player.speed;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    player.x += player.speed;
  }
  if (keyIsDown(UP_ARROW)) {
    player.y -= player.speed;
  }
  if (keyIsDown(DOWN_ARROW)) {
    player.y += player.speed;
  }

  if (player.x + player.size / 2 > width - 50 && player.x - player.size / 2 < width &&
      player.y + player.size / 2 > height - 50 && player.y - player.size / 2 < height) {
    gameWon = true;
  }
}

function drawPlayer() {
  fill(255, 0, 0);
  ellipse(player.x, player.y, player.size);
}

function drawShapes() {
  for (let shape of shapes) {
    fill(shape.color);
    noStroke();
    ellipse(shape.x, shape.y, shape.size);
  }
}

function mousePressed() {
  createShape(mouseX, mouseY);
}

function createShape(x, y) {
  shapes.push({
    x: x,
    y: y,
    size: random(20, 40),
    color: color(random(255), random(255), random(255)),
    xSpeed: random(-2, 2),
    ySpeed: random(-2, 2),
  });
}

function createObstacles(num) {
  for (let i = 0; i < num; i++) {
    let size = random(20, 40);
    shapes.push({
      x: random(width),
      y: random(height),
      size: size,
      color: color(random(255), random(255), random(255)),
      xSpeed: random(-2, 2),
      ySpeed: random(-2, 2),
    });
  }
}

function moveObstacles() {
  for (let shape of shapes) {
    shape.x += shape.xSpeed;
    shape.y += shape.ySpeed;

    if (shape.x < 0) shape.x = width;
    if (shape.x > width) shape.x = 0;
    if (shape.y < 0) shape.y = height;
    if (shape.y > height) shape.y = 0;
  }
}

function drawBorders() {
  stroke(0);
  noFill();
  rect(0, 0, width, height);
}

function drawExit() {
  fill(0, 255, 0);
  noStroke();
  rect(width - 50, height - 50, 50, 50);
}

function displayWinMessage() {
  fill(0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("You Win!", width / 2, height / 2);
}

