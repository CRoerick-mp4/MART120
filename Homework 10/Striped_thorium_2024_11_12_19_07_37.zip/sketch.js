let eyeX1 = 160, eyeX2 = 240;
let earY1 = 200, earY2 = 200;
let eyeSpeed1, eyeSpeed2;
let earSpeed1, earSpeed2;
let hairX = 200, hairY = 50;
let hairSpeedX, hairSpeedY;
let titleSize = 24;
let growing = true;
let growCounter = 0;

function setup() {
  createCanvas(400, 600);
  
  eyeSpeed1 = random(1, 2);
  eyeSpeed2 = random(1.5, 3);
  earSpeed1 = random(1, 3);
  earSpeed2 = random(2, 4);
  hairSpeedX = random(1, 2);
  hairSpeedY = random(1, 2);
}

function draw() {
  background(255);

  textAlign(CENTER);
  textSize(titleSize);
  text('Animated portrait of me!', width / 2, 30);
  
  if (growing) {
    titleSize += 2;
    growCounter++;
    if (growCounter >= 5) {
      growing = false;
    }
  } else {
    titleSize -= 2;
    growCounter--;
    if (growCounter <= 0) {
      growing = true;
    }
  }

  fill(220, 180, 150);
  noStroke();
  ellipse(200, 200, 150, 200);

  fill(255);
  ellipse(eyeX1, 160, 40, 40);
  ellipse(eyeX2, 160, 40, 40);

  fill(0);
  ellipse(eyeX1, 160, 15, 15);
  ellipse(eyeX2, 160, 15, 15);

  fill(220, 180, 150);
  triangle(200, 210, 195, 230, 205, 230);

  stroke(0);
  strokeWeight(2);
  line(170, 240, 230, 240);

  stroke(0);
  strokeWeight(4);
  line(140, 130, 180, 130);
  line(220, 130, 260, 130);

  fill(50, 50, 50);
  triangle(hairX - 75, hairY, hairX + 75, hairY, hairX, hairY - 70);
  
  hairX += hairSpeedX;
  hairY += hairSpeedY;
  if (hairX < 125 || hairX > 275) hairSpeedX *= -1;
  if (hairY < 40 || hairY > 120) hairSpeedY *= -1;

  fill(220, 180, 150);
  ellipse(100, earY1, 40, 60);
  ellipse(300, earY2, 40, 60);

  earY1 += earSpeed1;
  earY2 += earSpeed2;
  if (earY1 < 180 || earY1 > 220) earSpeed1 *= -1;
  if (earY2 < 180 || earY2 > 220) earSpeed2 *= -1;

  fill(0, 102, 204);
  rect(125, 350, 150, 200);

  fill(220, 180, 150);
  rect(75, 350, 50, 150);
  rect(275, 350, 50, 150);

  textSize(16);
  text('Carter Roerick', width / 2, height - 20);
}
